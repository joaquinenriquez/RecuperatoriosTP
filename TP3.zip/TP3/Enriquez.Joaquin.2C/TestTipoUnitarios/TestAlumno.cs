﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Clases_Instanciables;
using Excepciones;
using EntidadesAbstractas;

namespace TestTipoUnitarios
{
    [TestClass]
    public class TestAlumno
    {

        /// <summary>
        /// Prueba si se produce la excepcion de dni invalido
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(DniInvalidoException))]
        public void ProbarExcepcionDNI()
        {
            Alumno alumno1 = new Alumno(1, "Juan", "Pirulo", "-100", Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio);
        }

        /// <summary>
        /// Prueba si se produce la excepcion de nacionalidad invalida
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(NacionalidadInvalidaException))]
        public void ProbarExcepcionNacionalidad()
        {
            Alumno alumno1 = new Alumno(1, "Juan", "Pirulo", "100", Persona.ENacionalidad.Extranjero, Universidad.EClases.Laboratorio);
        }

        /// <summary>
        /// Prueba si la propiedad DNI devuelve un tipo int
        /// </summary>
        [TestMethod]
        public void ProbarDNInt()
        {
            Alumno alumno1 = new Alumno(1, "Juan", "Pirulo", "100", Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio);
            Assert.IsInstanceOfType(alumno1.DNI, typeof(int));
        }

        /// <summary>
        /// Prueba si la propiedad nombre no devuelve null
        /// </summary>
        [TestMethod]
        public void ProbarNombreNull()
        {
            Alumno alumno1 = new Alumno(1, "Juan", "Pirulo", "100", Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio);
            Assert.IsNotNull(alumno1.Nombre);
        }

    }
}
